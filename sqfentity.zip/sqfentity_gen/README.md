# sqfentity_gen

This package required for sqfentity ORM for Flutter code generator
Includes Generators and Converters with build.yaml

## Getting Started

click for more information: https://github.com/hhtokpinar/sqfEntity